export class CreateTypeDto {}
