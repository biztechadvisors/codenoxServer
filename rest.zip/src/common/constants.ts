export const APP_URL = 'http://localhost:5000/api';
// export const APP_URL = 'https://mock.redq.io/api';
