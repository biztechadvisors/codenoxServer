export class CoreGetArguments {
  id?: number;
  slug?: string;
}
