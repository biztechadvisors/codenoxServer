export class CreateNewSubscriberDto {
  email: string;
}
