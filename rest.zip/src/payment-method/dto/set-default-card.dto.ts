export class DefaultCart {
  method_id: string;
}
