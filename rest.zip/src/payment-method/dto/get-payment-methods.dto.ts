export class GetPaymentMethodsDto {
  text?: string;
}
