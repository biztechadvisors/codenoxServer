export class AddStaffDto {
  email: string;
  password: string;
  name: string;
  shop_id: number;
}
