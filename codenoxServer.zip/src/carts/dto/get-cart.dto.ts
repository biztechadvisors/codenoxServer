/* eslint-disable prettier/prettier */
export class GetCartData {
  customerId?: number
  email?: string
}