/* eslint-disable prettier/prettier */
export class CreateNewSubscriberDto {
  email: string
}
