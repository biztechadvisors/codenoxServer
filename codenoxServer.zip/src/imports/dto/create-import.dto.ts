/* eslint-disable prettier/prettier */
export class ImportDto {
  shop_id: number
  // csv: Upload;
}
