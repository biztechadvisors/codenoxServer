export class ImportDto {
  shop_id: number
  // csv: Upload;
}
