/* eslint-disable prettier/prettier */
export class GetTopManufacturersDto {
  limit: number
}
