/* eslint-disable prettier/prettier */
export class DefaultCart {
  method_id: number;
}
