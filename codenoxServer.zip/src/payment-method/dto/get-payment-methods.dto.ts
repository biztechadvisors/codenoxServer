/* eslint-disable prettier/prettier */
export class GetPaymentMethodsDto {
  text?: string
}
