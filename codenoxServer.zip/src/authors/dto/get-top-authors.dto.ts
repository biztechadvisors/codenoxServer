export class GetTopAuthorsDto {
  limit: number
}
