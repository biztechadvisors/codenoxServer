/* eslint-disable prettier/prettier */
export class CreateAiDto {
  prompt: string
}
