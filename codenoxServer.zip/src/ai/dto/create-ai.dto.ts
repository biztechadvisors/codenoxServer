export class CreateAiDto {
  prompt: string
}
