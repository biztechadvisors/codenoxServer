/* eslint-disable prettier/prettier */
export class CoreGetArguments {
  id?: number
  slug?: string
}
