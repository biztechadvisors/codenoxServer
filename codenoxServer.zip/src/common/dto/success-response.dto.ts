import { CoreMutationOutput } from './core-mutation-output.dto'

export class SuccessResponse extends CoreMutationOutput {}
