/* eslint-disable prettier/prettier */
import { CoreMutationOutput } from './core-mutation-output.dto'

export class SuccessResponse extends CoreMutationOutput {}
