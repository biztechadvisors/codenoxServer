/* eslint-disable prettier/prettier */

export class AttachmentDTO {
  id?: number
  thumbnail: string = '';
  original: string = '';
}
