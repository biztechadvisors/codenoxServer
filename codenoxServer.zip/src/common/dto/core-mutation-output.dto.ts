/* eslint-disable prettier/prettier */
export class CoreMutationOutput {
  message: string
  success: boolean
}
