export class CoreMutationOutput {
  message: string
  success: boolean
}
