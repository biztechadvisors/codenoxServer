export class CreateNotificationDto {
    readonly message: string;
    readonly title: string;
}
